/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ibd.transaction.log;

import ibd.Table;
import ibd.transaction.SimulatedIterations;
import ibd.transaction.Transaction;
import java.io.RandomAccessFile;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

/**
 *
 * @author pccli
 */
public class Logger {

    ArrayList<Entry> entries = new ArrayList();
    String file;
    int start = 0;
    
    RandomAccessFile log;

    public Logger(String folder, String name) throws Exception {
        
        Path path = Paths.get(folder);
        Files.createDirectories(path);
            
        file = folder+"\\"+name;
        log = new RandomAccessFile(file, "rw");
        
        
    }

    public void transactionStart(Transaction transaction)  throws Exception {

        transaction.setLogger(this);

        StartEntry entry = new StartEntry();
        entry.setTransactionId(transaction.getId());
        entries.add(entry);
        writeLog();
    }

    public void transactionCommit(Transaction transaction)  throws Exception {
        CommitEntry entry = new CommitEntry();
        entry.setTransactionId(transaction.getId());
        entries.add(entry);
        writeLog();
    }

    public void transactionAbort(Transaction transaction)  throws Exception  {
        AbortEntry entry = new AbortEntry();
        entry.setTransactionId(transaction.getId());
        entries.add(entry);
        writeLog();
    }

    public void transactionWrite(Transaction transaction, Table table, long pk, String oldValue, String newValue)  throws Exception  {
        WriteEntry entry = new WriteEntry();
        entry.table = table;
        entry.pk = pk;
        entry.oldValue = oldValue;
        entry.newValue = newValue;
        entry.setTransactionId(transaction.getId());
        entries.add(entry);
        writeLog();
    }

    
    public void writeLog() throws Exception {
        
        for (int x = start; x < entries.size(); x++) {
            log.writeBytes(entries.get(x).write());
            log.writeBytes(System.lineSeparator());
        }
        start = entries.size();

    }
    
    
    
    public void recover() throws Exception {
        
        readLog();
        
        recover1();
        
        clear();
    
    }
    
    
    
    private void readLog() throws Exception{
    RandomAccessFile readLog = new RandomAccessFile(file, "rw");
        
        try {
            String line = readLog.readLine();
            Entry entry = null;
            while (line != null) {
                if (line.charAt(0) == 'C') {
                    entry = new CommitEntry();
                } 
                else if (line.charAt(0) == 'A') {
                    entry = new AbortEntry();
                }
                else if (line.charAt(0) == 'S') {
                    entry = new StartEntry();
                } 
                else {
                    entry = new WriteEntry();
                }

                entry.read(line);
                entries.add(entry);

                line = readLog.readLine();
            }

        } finally {
            readLog.close();
        }
    
    }
    
    public void clear() throws Exception{
        new RandomAccessFile(file, "rw").setLength(0);
        entries.clear();
    }
    
    private void recover1() throws Exception{
    }
    
    
}
