C# com JSON
Integrantes:
	Frederico Gassen
	Maurício Schmaedeck

Pré-requisitos:
	* .NET Framework 4.5
	* Json.NET
	* Json.NET Schema
	* Visual Studio 2019 (recomendado)

Para compilar o projeto:
	1. Abrir a solução (.sln) no Visual Studio
	2. No explorador da solução, clicar com o botão direito e selecionar Restaurar Pacotes NuGet
		2.1 Este passo irá baixar as dependências do projeto
	3. No explorador da solução, clicar com o botão direito e selecionar Compilar Solução